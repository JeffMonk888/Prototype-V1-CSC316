# What They Carry — Prototype V1 submission (code + cleaned data)

Static D3 v7 site for the CSC316 final project. Open it through a local server, not by double-clicking
`index.html` (ES modules and `d3.csv` need http):

```bash
cd Submission
python3 -m http.server 8000
# then open http://localhost:8000
```

On GitHub Pages: push this folder's contents to the repo root (or `docs/`) and enable Pages.

## Layout
| Path | What it is |
|---|---|
| `index.html` | The whole story: 9 scenes in storyboard order (prologue → hook → choose → two storylines → aha → staircase → solution → about). Placeholders are marked with a dashed border and a "Planned" tag. |
| `css/style.css` | Design tokens (amber = behaviour, indigo = mental health; light + dark) and page layout. |
| `css/dumbbell.css`, `css/bullyingFlow.css` | Chart styles; both use only the tokens. |
| `js/state.js` | The one shared state (`countrychange`) that links the top bar and every chart. |
| `js/main.js` | Loads `data/*.csv`, mounts the charts, wires the progress rail. |
| `js/charts/dumbbellChart.js` | **Vis A (working):** bullied vs not bullied, four outcomes, animated country switch, CIs, tooltips, table fallback. |
| `js/charts/bullyingFlowChart.js` | **Vis B (working, novel view):** bullied → mental-health signs → missed school flow (HC). |
| `data/clean/gshs_clean.csv` | The cleaned dataset (Step 2): 18,765 students aged 13–17, 95 columns, built from the four WHO GSHS files. |
| `data/dumbbell.csv` | From `scripts/export_dumbbell.py` (reads `data/clean/gshs_clean.csv`). |
| `data/bullying_flow*.csv` | From `scripts/export_bullying_flow.py` (HC). |

## Rebuilding the data
```bash
python3 scripts/export_dumbbell.py
```
Values are survey-weighted % with 2 decimals; round only at display (`d3.format(".0f")`).

## Adding a chart
1. Export its numbers to `data/` with a script (never type numbers into JS).
2. Write `js/charts/<name>.js` exporting `function <name>(selector, data, state)`; listen with `state.on("countrychange.<name>", ...)` and call `state.call("countrychange", null, iso3)` from its own buttons.
3. Replace the matching `.chart.placeholder` block in `index.html` with a `<div id="...">` and mount it in `main.js`.
