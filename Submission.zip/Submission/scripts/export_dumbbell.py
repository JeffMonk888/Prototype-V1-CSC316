"""export_dumbbell.py — data for the "Same Weight" dumbbell chart (Vis A).

Reads data/clean/gshs_clean.csv (the team's cleaned file, Step 2) and writes site data/dumbbell.csv:
one row per country x outcome x group (Bullied / Not bullied) with the survey-weighted %
of students aged 13-17, a 95% school-level (PSU) bootstrap CI and the unweighted n.

Duplicate rows (flag_duplicate_row = 1) are dropped, matching the figures in the
Prototype V1 dumbbell. Run from the website folder:
    python3 scripts/export_dumbbell.py
"""
import sys
import numpy as np
import pandas as pd

SRC = sys.argv[1] if len(sys.argv) > 1 else "data/clean/gshs_clean.csv"
OUT = "data/dumbbell.csv"
OUTCOMES = [
    ("considered_suicide", "Seriously considered suicide", "past 12 months"),
    ("attempted_suicide", "Attempted suicide", "past 12 months"),
    ("lonely", "Felt lonely most of the time", "past 12 months"),
    ("truant", "Missed school without permission", "past 30 days"),
]
COUNTRY = {"Trinidad and Tobago": "Trinidad & Tobago"}
BOOT, SEED = 500, 316

df = pd.read_csv(SRC, low_memory=False)
df = df[df.flag_duplicate_row == 0]
rng = np.random.default_rng(SEED)
rows = []
for iso, g in df.groupby("iso3"):
    meta = g.iloc[0]
    for col, label, window in OUTCOMES:
        for b, grp in ((1, "Bullied"), (0, "Not bullied")):
            s = g[(g.bullied == b) & g[col].notna()]
            pct = 100 * np.average(s[col], weights=s.weight)
            # cluster bootstrap: resample schools (psu_id) with replacement
            psus = s.psu_id.unique()
            by_psu = {p: (s.loc[s.psu_id == p, col].to_numpy(), s.loc[s.psu_id == p, "weight"].to_numpy()) for p in psus}
            reps = []
            for _ in range(BOOT):
                pick = rng.choice(psus, size=len(psus), replace=True)
                v = np.concatenate([by_psu[p][0] for p in pick]); w = np.concatenate([by_psu[p][1] for p in pick])
                reps.append(100 * np.average(v, weights=w))
            lo, hi = np.percentile(reps, [2.5, 97.5])
            rows.append(dict(iso3=iso, country=COUNTRY.get(meta.country, meta.country), income_group=meta.income_group,
                             income_rank=int(meta.income_rank), survey_year=int(meta.survey_year),
                             outcome=col, outcome_label=label, window=window, group=grp,
                             pct=round(pct, 2), ci_low=round(lo, 2), ci_high=round(hi, 2), n=len(s)))
out = pd.DataFrame(rows).sort_values(["income_rank", "outcome", "group"])
out.to_csv(OUT, index=False)
print(out.to_string(index=False))
