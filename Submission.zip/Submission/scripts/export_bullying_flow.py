"""
export_bullying_flow.py — Data for the bullying flow chart (sketch 13, the designated novel vis).

Question: "Are bullied students more likely to report poor mental health and unauthorized absence?"

Three stages, one row per student who answered all four items:
    1. Bullied        : bullied (past 30 days)                      -> Bullied / Not bullied
    2. Mental health  : number of signs among SIGNS (below)         -> Both signs / One sign / No signs
    3. Absence        : truant (missed school without permission,   -> Missed school / Did not miss
                        past 30 days)

Writes (survey-weighted, 2 decimals; round only when displaying):
    site/data/bullying_flow.csv        one row per country x path (2 x 3 x 2 = 12 paths); band widths
    site/data/bullying_flow_rates.csv  conditional % with 95% CIs, for tooltips and the table fallback

    python3 scripts/export_bullying_flow.py      (~1 min: builds the 500 bootstrap replicates)
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from analysis_lib import ISOS, NAMES, ROOT, _ci, load  # noqa: E402

OUT = ROOT / "site" / "data"

# The two "mental health signs". Team decision: change here and re-run if you want different signs.
SIGNS = {"lonely": "Lonely most of the time or always",
         "worry_no_sleep": "Too worried to sleep most of the time or always"}

BULLIED = {1: "Bullied", 0: "Not bullied"}
SIGN_LEVEL = {2: "Both signs", 1: "One sign", 0: "No signs"}
ABSENCE = {1: "Missed school", 0: "Did not miss"}
RANK = {iso: i + 1 for i, iso in enumerate(ISOS)}


def main():
    df, W = load()
    need = ["bullied", "truant", *SIGNS]
    keep = df[need].notna().all(axis=1).to_numpy()

    b = df["bullied"].to_numpy()
    s = df[list(SIGNS)].sum(axis=1).to_numpy()
    a = df["truant"].to_numpy()
    w = df["weight"].to_numpy()

    paths, rates = [], []
    for iso in ISOS:
        base = keep & (df["iso3"] == iso).to_numpy()
        tot = w[base].sum()

        # ---- band widths: weighted % of the country's students on each full path ----
        for bv in (1, 0):
            for sv in (2, 1, 0):
                for av in (1, 0):
                    m = base & (b == bv) & (s == sv) & (a == av)
                    paths.append(dict(iso3=iso, country=NAMES[iso], income_rank=RANK[iso],
                                      bullied=BULLIED[bv], signs=SIGN_LEVEL[sv], absence=ABSENCE[av],
                                      pct_of_students=round(100 * w[m].sum() / tot, 2), n=int(m.sum())))

        # ---- conditional rates with bootstrap CIs ----
        def rate(given, event, **labels):
            idx = np.where(given)[0]
            ev = event[idx].astype(float)
            p = 100 * (w[idx] * ev).sum() / w[idx].sum()
            with np.errstate(invalid="ignore", divide="ignore"):
                rep = 100 * (W[idx] * ev[:, None]).sum(0) / W[idx].sum(0)
            lo, hi = _ci(rep)
            rates.append(dict(iso3=iso, country=NAMES[iso], income_rank=RANK[iso],
                              bullied=labels.get("bullied", "All students"), signs=labels.get("signs", "Any"),
                              outcome=labels["outcome"], pct=round(p, 2), ci_low=round(lo, 2), ci_high=round(hi, 2),
                              n=int(len(idx))))

        for bv in (1, 0):
            gb = base & (b == bv)
            for sv in (2, 1, 0):                                   # stage 1 -> 2
                rate(gb, s == sv, bullied=BULLIED[bv], outcome=SIGN_LEVEL[sv])
            rate(gb, s >= 1, bullied=BULLIED[bv], outcome="At least one sign")  # for the subtitle
            rate(gb, a == 1, bullied=BULLIED[bv], outcome="Missed school")  # stage 1 -> 3 (headline)
            for sv in (2, 1, 0):                                   # stage 2 -> 3, by colour
                rate(gb & (s == sv), a == 1, bullied=BULLIED[bv], signs=SIGN_LEVEL[sv], outcome="Missed school")
        for sv in (2, 1, 0):                                       # node level, all students
            rate(base & (s == sv), a == 1, signs=SIGN_LEVEL[sv], outcome="Missed school")
        rate(base, b == 1, outcome="Bullied")

    pd.DataFrame(paths).to_csv(OUT / "bullying_flow.csv", index=False)
    pd.DataFrame(rates).to_csv(OUT / "bullying_flow_rates.csv", index=False)
    print("wrote", OUT / "bullying_flow.csv", "and", OUT / "bullying_flow_rates.csv")


if __name__ == "__main__":
    main()
