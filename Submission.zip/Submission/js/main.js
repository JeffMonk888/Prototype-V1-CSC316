/**
 * main.js — wires the page together: loads the data files, mounts the two working D3 charts,
 * and connects everything to the shared state (linked views) and the progress rail.
 */
import { state, COUNTRIES, byIso, DEFAULT_COUNTRY } from "./state.js";
import { dumbbellChart } from "./charts/dumbbellChart.js";
import { bullyingFlowChart } from "./charts/bullyingFlowChart.js";

// ---------- sticky bar: "Following:" pill + country buttons ----------
const pill = d3.select("#following-pill");
const topToggle = d3.select("#country-toggle");
topToggle.selectAll("button").data(COUNTRIES).join("button")
  .attr("type", "button").text((d) => d.country)
  .on("click", (event, d) => state.call("countrychange", null, d.iso3));

state.on("countrychange.topbar", (iso) => {
  const c = byIso.get(iso);
  pill.text(c ? c.country : "");
  topToggle.selectAll("button").attr("aria-pressed", (d) => d.iso3 === iso);
  d3.selectAll("[data-country-name]").text(c ? c.country : "");
});

// ---------- charts ----------
const fail = (sel) => (err) => {
  d3.select(sel).append("p").attr("class", "note")
    .text("Could not load the data file. Open the site through a local server (python3 -m http.server 8000) or GitHub Pages, not file://.");
  console.error(err);
};

Promise.all([d3.csv("data/dumbbell.csv")])
  .then(([rows]) => { dumbbellChart("#dumbbell", rows, state); state.call("countrychange", null, DEFAULT_COUNTRY); })
  .catch(fail("#dumbbell"));

Promise.all([d3.csv("data/bullying_flow.csv"), d3.csv("data/bullying_flow_rates.csv")])
  .then(([paths, rates]) => { bullyingFlowChart("#bullying-flow", { paths, rates }, state); state.call("countrychange", null, DEFAULT_COUNTRY); })
  .catch(fail("#bullying-flow"));

state.call("countrychange", null, DEFAULT_COUNTRY);

// ---------- progress rail: highlight the scene in view ----------
const scenes = document.querySelectorAll("section.scene[id]");
const dots = new Map([...document.querySelectorAll(".rail a")].map((a) => [a.getAttribute("href").slice(1), a]));
if ("IntersectionObserver" in window) {
  const io = new IntersectionObserver((entries) => {
    entries.forEach((e) => { if (e.isIntersecting) { dots.forEach((a) => a.removeAttribute("aria-current")); const a = dots.get(e.target.id); if (a) a.setAttribute("aria-current", "true"); } });
  }, { rootMargin: "-40% 0px -50% 0px" });
  scenes.forEach((s) => io.observe(s));
}
