/**
 * state.js — the one shared state for the whole story (linked views).
 *
 * Every chart and the sticky "Following:" bar listen to the same dispatcher, so a country picked
 * anywhere updates everywhere. Charts call `state.call("countrychange", null, iso3)` when the
 * reader clicks their country buttons and subscribe with a namespaced listener:
 *   state.on("countrychange.myChart", (iso3) => { ... });
 *
 * Events
 *   countrychange  (iso3: "TZA" | "PHL" | "THA" | "TTO")
 *   homechange     (home background; reserved for Vis 2 "no empty cell", not used in V1)
 */
export const state = d3.dispatch("countrychange", "homechange");

/** Countries in income order; the same list drives every selector on the page. */
export const COUNTRIES = [
  { iso3: "TZA", country: "Tanzania", income_group: "Low income", survey_year: 2014, income_rank: 1 },
  { iso3: "PHL", country: "Philippines", income_group: "Lower-middle income", survey_year: 2015, income_rank: 2 },
  { iso3: "THA", country: "Thailand", income_group: "Upper-middle income", survey_year: 2015, income_rank: 3 },
  { iso3: "TTO", country: "Trinidad & Tobago", income_group: "High income", survey_year: 2017, income_rank: 4 },
];
export const byIso = new Map(COUNTRIES.map((c) => [c.iso3, c]));
export const DEFAULT_COUNTRY = "TZA";
